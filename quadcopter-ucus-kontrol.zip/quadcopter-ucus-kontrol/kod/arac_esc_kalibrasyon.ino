/* ===========================================================================
 *  ARAC KODU - ESC UC NOKTA KALIBRASYONU  (RMT / 50 Hz)
 *  Dosya : arac_esc_kalibrasyon.ino
 *  Surum : v3.0  - LEDC birakildi, RMT cevre birimine gecildi
 *
 *  Darbe uretimi ucus yazilimiyla AYNI YONTEMLE yapilir (RMT, 50 Hz).
 *  Kalibrasyon, ESC'nin gordugu sinyalin butununu referans aldigi icin
 *  bu sart - farkli yontemle kalibre edilirse ucusta senkron tutmaz.
 *
 *  PROSEDUR
 *    1. Batarya TAKILI DEGIL. Pervaneler TAKILI DEGIL.
 *    2. Kodu yukle, seri monitoru ac (115200).
 *    3. "MAX sinyal aktif" yazisini gorunce bataryayi tak.
 *    4. Bip seslerini dinle - ESC ust noktayi kaydeder.
 *    5. 10 sn sonra alt noktaya gecer, onay bipleri gelir.
 *    6. 'h' gonderip dort motorun SENKRON dondugunu dogrula.
 * ======================================================================== */

/* Motor pinleri - UCUS KODUYLA AYNI OLMALI */
#define PIN_M1   25   // on-sag , CW
#define PIN_M2   26   // arka-sag, CCW
#define PIN_M3   32   // arka-sol, CW
#define PIN_M4   33   // on-sol , CCW

const uint8_t MOTOR_PIN[4] = { PIN_M1, PIN_M2, PIN_M3, PIN_M4 };

const uint16_t PWM_MIN        = 1000;
const uint16_t PWM_MAX        = 2000;
const uint32_t PWM_PERIYOT_US = 20000;    // 50 Hz
const uint32_t RMT_TIK_HZ     = 1000000;  // 1 us cozunurluk

rmt_data_t motorSembol[4][1];
uint16_t   motorHedef[4] = { PWM_MIN, PWM_MIN, PWM_MIN, PWM_MIN };

bool motorKur() {
  bool ok = true;
  for (int i = 0; i < 4; i++)
    if (!rmtInit(MOTOR_PIN[i], RMT_TX_MODE, RMT_MEM_NUM_BLOCKS_1, RMT_TIK_HZ))
      ok = false;
  return ok;
}

void motorlariGonder() {
  for (int i = 0; i < 4; i++) {
    motorSembol[i][0].level0    = 1;
    motorSembol[i][0].duration0 = motorHedef[i];
    motorSembol[i][0].level1    = 0;
    motorSembol[i][0].duration1 = PWM_PERIYOT_US - motorHedef[i];
    rmtWrite(MOTOR_PIN[i], motorSembol[i], 1, 0);
  }
}

void hepsineAyarla(uint16_t us) {
  for (int i = 0; i < 4; i++) motorHedef[i] = constrain(us, PWM_MIN, PWM_MAX);
}

/* Belirtilen sure boyunca 50 Hz'de darbe uretmeyi surdurur.
   ESC sinyal kesilmesini ariza sayar, bu yuzden bekleme sirasinda da
   gonderim devam etmelidir - duz delay() KULLANILAMAZ.               */
void bekleVeGonder(uint32_t sure_ms) {
  uint32_t bas = millis();
  while (millis() - bas < sure_ms) {
    motorlariGonder();
    delay(20);
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("\n=== ESC KALIBRASYONU - RMT / 50 Hz ==="));
  Serial.println(F("Pervaneler SOKULU. Batarya HENUZ TAKILI DEGIL."));
  Serial.println();

  if (!motorKur()) {
    Serial.println(F("[HATA] RMT baslatilamadi"));
    while (1) delay(500);
  }

  hepsineAyarla(PWM_MAX);
  Serial.println(F(">>> MAX sinyal aktif (2000 us)"));
  Serial.println(F("    SIMDI bataryayi tak. Bip seslerini bekle."));
  bekleVeGonder(10000);

  hepsineAyarla(PWM_MIN);
  Serial.println(F(">>> MIN sinyal aktif (1000 us)"));
  Serial.println(F("    Onay bipleri gelmeli."));
  bekleVeGonder(5000);

  Serial.println(F("\n=== KALIBRASYON BITTI ==="));
  Serial.println(F("1-4 : o motoru tek basina 3 sn dondur"));
  Serial.println(F("h   : dort motor birden - SENKRON TESTI"));
  Serial.println(F("0   : durdur\n"));
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();

    if (c >= '1' && c <= '4') {
      int m = c - '1';
      Serial.print(F(">> Motor ")); Serial.print(m + 1);
      Serial.println(F(" 3 saniye donuyor"));
      hepsineAyarla(PWM_MIN);
      motorHedef[m] = 1150;
      bekleVeGonder(3000);
      hepsineAyarla(PWM_MIN);
      Serial.println(F("   durdu"));
    }

    if (c == 'h') {
      Serial.println(F(">> DORT MOTOR birden 3 saniye (senkron testi)"));
      hepsineAyarla(1150);
      bekleVeGonder(3000);
      hepsineAyarla(PWM_MIN);
      Serial.println(F("   durdu"));
    }

    if (c == '0') {
      hepsineAyarla(PWM_MIN);
      Serial.println(F(">> HEPSI DURDU"));
    }
  }

  motorlariGonder();
  delay(20);
}
