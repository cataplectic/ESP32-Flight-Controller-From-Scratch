/* =========================================================================
 *  MINIMAL TELSIZ TESTI - VERICI
 *  Amac: nRF24 baglantisini TEK BASINA olcmek. Joystick, PID, motor yok.
 *
 *  Sonuc %95+ ise    -> telsiz saglam, sorun ana koddaki etkilesimde
 *  Sonuc yine %50 ise -> sorun donanimda (modul, besleme, anten)
 * ====================================================================== */
#include <SPI.h>
#include <RF24.h>

RF24 radio(4, 5);
const byte ADRES[6] = "DRN01";

struct Paket { uint16_t kanal[4]; uint16_t sayac; };  // ana kodla ayni boyut
Paket veri;

uint32_t son = 0, yaz = 0;
uint16_t gonderilen = 0, basarili = 0;

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("\n=== MINIMAL TELSIZ TESTI - VERICI ==="));

  if (!radio.begin()) {
    Serial.println(F("[HATA] nRF24 bulunamadi"));
    while (1) delay(500);
  }

  radio.openWritingPipe(ADRES);
  radio.setPALevel(RF24_PA_MIN);     // EN DUSUK guc - yakin mesafe testi
  radio.setDataRate(RF24_1MBPS);
  radio.setChannel(115);
  radio.setRetries(5, 5);
  radio.stopListening();

  Serial.println(F("[OK] Hazir. PA_MIN, 1 Mbps, kanal 115\n"));
  radio.printPrettyDetails();
  Serial.println();
}

void loop() {
  uint32_t simdi = millis();
  if (simdi - son < 20) return;      // 50 Hz
  son = simdi;

  veri.kanal[0] = 1000;
  veri.kanal[1] = 1500;
  veri.kanal[2] = 1500;
  veri.kanal[3] = 1500;
  veri.sayac++;

  if (radio.write(&veri, sizeof(veri))) basarili++;
  gonderilen++;

  if (simdi - yaz >= 1000) {         // saniyede bir ozet
    yaz = simdi;
    Serial.print(F("gonderilen:")); Serial.print(gonderilen);
    Serial.print(F("  ACK:"));      Serial.print(basarili);
    Serial.print(F("  basari:"));
    Serial.print((basarili * 100UL) / gonderilen);
    Serial.println(F("%"));
    gonderilen = 0;
    basarili   = 0;
  }
}
