/* =========================================================================
 *  MINIMAL TELSIZ TESTI - ALICI
 *  Amac: nRF24 baglantisini TEK BASINA olcmek. MPU, ESC, PID yok.
 *  Verici koduyla ayni anda calistirilir.
 * ====================================================================== */
#include <SPI.h>
#include <RF24.h>

RF24 radio(4, 5);
const byte ADRES[6] = "DRN01";

struct Paket { uint16_t kanal[4]; uint16_t sayac; };
Paket gelen;

uint32_t yaz = 0;
uint16_t sonSayac = 0;
uint32_t alinan = 0, kayip = 0;

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("\n=== MINIMAL TELSIZ TESTI - ALICI ==="));

  if (!radio.begin()) {
    Serial.println(F("[HATA] nRF24 bulunamadi"));
    while (1) delay(500);
  }

  radio.openReadingPipe(0, ADRES);
  radio.setPALevel(RF24_PA_MIN);
  radio.setDataRate(RF24_1MBPS);
  radio.setChannel(115);
  radio.startListening();

  Serial.println(F("[OK] Dinlemede. PA_MIN, 1 Mbps, kanal 115\n"));
  radio.printPrettyDetails();
  Serial.println();
}

void loop() {
  if (radio.available()) {
    radio.read(&gelen, sizeof(gelen));
    alinan++;

    if (sonSayac != 0) {
      uint16_t fark = gelen.sayac - sonSayac;
      if (fark > 1) kayip += fark - 1;
    }
    sonSayac = gelen.sayac;
  }

  if (millis() - yaz >= 1000) {
    yaz = millis();
    Serial.print(F("alinan:")); Serial.print(alinan);
    Serial.print(F("  kayip:")); Serial.print(kayip);
    uint32_t toplam = alinan + kayip;
    if (toplam > 0) {
      Serial.print(F("  basari:"));
      Serial.print((alinan * 100UL) / toplam);
      Serial.print(F("%"));
    }
    Serial.println();
    alinan = 0;
    kayip  = 0;
  }
}
